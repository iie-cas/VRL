#include <stdio.h>

void vul(){
}

void open_a_shell(){
	system("/bin/sh");
}

void print_something(){
	printf("hello");
}

int main(void){ 
	void (*f)() = print_something;
	void (**p)() = &f;
	f();
	char a[100];
	scanf("%s",a);
	printf(a);
	f();
	return 0;
}

