#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

typedef struct vul{
	int d1[24];
	void(*fp)();
}vul;

void test(){
	printf("hello!\n");
}

void hack(){
	system("/bin/sh");
}

void useAfterFree(char *str){
	vul *p = (vul *)malloc(sizeof(vul));
	p->fp = test;
	free(p);
	char *p2 = (char*)malloc(101);
	strcpy(p2, str);
	p -> fp();
}

int main(){
	char s[101];
	gets(s);
	useAfterFree(s);
	return 0;
}
